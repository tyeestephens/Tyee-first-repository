function setup() {
  createCanvas(400, 400);
  colorMode(HSB, 360, 100, 100); 
}

function draw() {
  background(200, 206, 250); 

  noStroke();

  let centerX = 200;
  let centerY = 200;
  let petalWidth = 80;
  let petalHeight = 50;
  let stemWidth = 20;
  let stemHeight = 150;
  let stemX = centerX - stemWidth / 2;
  let stemY = centerY;

  fill(100, 80, 50); 
  rect(0, 350, width, 50); 

  
  fill(100, 80, 50); 
  rect(stemX, stemY, stemWidth, stemHeight);

  drawGradientPetal(centerX - petalWidth / 2, centerY, petalWidth, petalHeight, 320, 350); // Left petal
  drawGradientPetal(centerX + petalWidth / 2, centerY, petalWidth, petalHeight, 320, 350); // Right petal
  drawGradientPetal(centerX, centerY - petalWidth / 2, petalHeight, petalWidth, 320, 350); // Top petal
  drawGradientPetal(centerX, centerY + petalWidth / 2, petalHeight, petalWidth, 320, 350); // Bottom petal

  fill(50, 100, 100); //
  ellipse(centerX, centerY, 40);

  drawCloud(100, 50);
  drawCloud(250, 80);
  drawCloud(300, 40);
}


function drawGradientPetal(x, y, w, h, hueStart, hueEnd) {
  let steps = 5; 
  for (let i = 0; i < steps; i++) {
    let interpHue = map(i, 0, steps, hueStart, hueEnd); 
    fill(interpHue, 80, 90); 
    ellipse(x, y, w - i * 5, h - i * 5); 
  }
}

function drawCloud(x, y) {
  fill(0, 0, 100); // 
  ellipse(x, y, 50, 40);
  ellipse(x + 20, y - 10, 50, 40);
  ellipse(x + 40, y, 50, 40);
  ellipse(x + 20, y + 10, 50, 40);
}
