function setup() {
  createCanvas(400, 400);
}

function draw() {
  background("blue");
function draw() {
} triangle(130,100, 170, 80, 170,130)
 ellipse(100, 100, 75, 50)
 fill("black")
  ellipse(75, 100, 20, 20)
  fill("White")
  ellipse(75, 100, 10, 18)
  fill(200, 180, 140)
 rect(0, 200, 400, 200)
}